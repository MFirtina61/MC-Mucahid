<div class="single"> 
    <img src="<?= $single["image"] ?>" alt=" <? $single["title"] ?>">
    <h3>
        <?= $single["title"] ?>
    </h3>
    <p>Artiest:
        <?= $single["artist"] ?>
    </p>
    <p>Leeftijd:
        <?= $single["leeftijd"] ?>
    </p>
    <p>Genre:
        <?= $single["genre"] ?> 
    </p>
</div>