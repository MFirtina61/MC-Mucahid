
<?php
// Gegevens van muziek singles
$musicSingles = [
    [
        "title" => "Weeknd - Starboy ft. Daft Punk",
        "artist" => "Weekend",
        "leeftijd" => "33",
        "genre" => "HipHop",
        "image" => "/img/album1.jpg"
    ],
    [
        "title" => "Michael Jackson - Billie Jean",
        "artist" => "Micheal Jackson",
        "leeftijd" => "50",
        "genre" => "Pop",
        "image" => "/img/micheal.jpg"
    ],
    [
        "title" => "XXXTENTACION - MOONLIGHT",
        "artist" => "XXXTENTACION",
        "leeftijd" => "20",
        "genre" => "rap",
        "image" => "/img/xxxtentation.webp"
    ],
    [
        "title" => "XXXTENTACION - MOONLIGHT",
        "artist" => "XXXTENTACION",
        "leeftijd" => "20",
        "genre" => "rap",
        "image" => "/img/xxxtentation.webp"
    ],   [
        "title" => "XXXTENTACION - MOONLIGHT",
        "artist" => "XXXTENTACION",
        "leeftijd" => "20",
        "genre" => "rap",
        "image" => "/img/xxxtentation.webp"
    ],   [
        "title" => "XXXTENTACION - MOONLIGHT",
        "artist" => "XXXTENTACION",
        "leeftijd" => "20",
        "genre" => "rap",
        "image" => "/img/xxxtentation.webp"
    ]

    
    // Voeg hier meer gegevens toe
];